import json
import google.generativeai as genai
from django.conf import settings

genai.configure(api_key=settings.GEMINI_API_KEY)


# WBS PROMPT 

WBS_PROMPT_TEMPLATE = """
You are an AI specialized in software project management.
Your task is to convert the given project scope into a structured set of project ACTIVITIES, each with a list of detailed tasks.

IMPORTANT INSTRUCTIONS:
- The input may be in English OR Arabic. Handle both languages properly.
- Output MUST be ONLY valid JSON.
- JSON structure MUST follow exactly this format:
{{
  "project_name": "string",
  "activities": [
    {{
      "name": "string",
      "tasks": [
        {{ "id": "X.Y", "name": "string", "effort_days": integer }}
      ]
    }}
  ]
}}

GUIDELINES:
- "project_name" should summarize the scope in a clean title.
- Create 4–7 activities based on software project lifecycle (e.g., Planning, Requirements, Analysis, Design, Implementation, Testing ,Documentation).
- Each activity must contain 3–8 tasks, each task with realistic integer effort_days.
- Ensure the output aligns with real-world software engineering practices (Agile, SDLC, Scrum, DevOps).

PROJECT SCOPE:
{scope}

Provide ONLY valid JSON output without explanations.
"""

# FUNCTION: generate_wbs_from_scope

def generate_wbs_from_scope(scope_text: str) -> dict:
    """
    Uses Google Gemini (Generative AI) to generate the WBS.
    Returns output as a Python dict.
    """

    # شرط عدد الكلمات
    if len(scope_text.split()) < 5:
        raise ValueError("يجب إدخال وصف مشروع يحتوي على 5 كلمات على الأقل")

    if not settings.GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY is not set in .env")


    if not settings.GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY is not set in .env")

    prompt = WBS_PROMPT_TEMPLATE.format(scope=scope_text)

    model = genai.GenerativeModel("gemini-2.0-flash")

    response = model.generate_content(prompt)

    content = response.text

    content = content.strip().replace("```json", "").replace("```", "")

    try:
        return json.loads(content)
    except json.JSONDecodeError:
        raise ValueError(f"Gemini returned invalid JSON:\n{content}")
